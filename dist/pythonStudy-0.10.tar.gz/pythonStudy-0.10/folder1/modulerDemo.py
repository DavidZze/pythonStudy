#!/usr/bin/python
# -*- coding: utf-8 -*-


def printme(var):
  print var
if __name__ == '__main__':
    printme(1)
