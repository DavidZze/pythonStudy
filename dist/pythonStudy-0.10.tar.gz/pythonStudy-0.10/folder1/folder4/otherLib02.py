#!/usr/bin/python
# -*- coding: utf-8 -*-

def square_sum(a,b):
    c = a**2 + b**2
    # 返回c的值，也就是输出的功能。Python的函数允许不返回值，也就是不用return。
    return c

