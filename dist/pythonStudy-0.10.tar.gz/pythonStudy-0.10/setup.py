from setuptools import setup, find_packages
setup(
      name="pythonStudy",
      version="0.10",
      description="My test module",
      author="Zhouze",
      url="http://www.csdn.net",
      license="LGPL",
      packages= find_packages(),
      scripts=["scripts/test.py"],
      )




