#!/usr/bin/python
# -*- coding: utf-8 -*-


import Levenshtein
import Levenshtein.StringMatcher as strMatcher


print Levenshtein._levenshtein
a = strMatcher.__doc__
print a